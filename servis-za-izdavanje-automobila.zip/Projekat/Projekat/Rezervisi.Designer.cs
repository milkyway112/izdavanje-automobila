﻿namespace Projekat
{
    partial class Rezervisi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbxMarka = new System.Windows.Forms.ComboBox();
            this.cbxKubikaza = new System.Windows.Forms.ComboBox();
            this.cbxModel = new System.Windows.Forms.ComboBox();
            this.cbxGorivo = new System.Windows.Forms.ComboBox();
            this.cbxKaroserija = new System.Windows.Forms.ComboBox();
            this.cbxPogon = new System.Windows.Forms.ComboBox();
            this.cbxGodiste = new System.Windows.Forms.ComboBox();
            this.cbxBrojVrata = new System.Windows.Forms.ComboBox();
            this.cbxMenjac = new System.Windows.Forms.ComboBox();
            this.lblMarka = new System.Windows.Forms.Label();
            this.lblKubikaza = new System.Windows.Forms.Label();
            this.lblGorivo = new System.Windows.Forms.Label();
            this.lblModel = new System.Windows.Forms.Label();
            this.lblKaroserija = new System.Windows.Forms.Label();
            this.lblPogon = new System.Windows.Forms.Label();
            this.lblGodiste = new System.Windows.Forms.Label();
            this.lblBrojVrata = new System.Windows.Forms.Label();
            this.lblMenjac = new System.Windows.Forms.Label();
            this.btnPrikaziTermine = new System.Windows.Forms.Button();
            this.lblDatumPreuzimanja = new System.Windows.Forms.Label();
            this.lblUkupnaCena = new System.Windows.Forms.Label();
            this.lblDatumVracanja = new System.Windows.Forms.Label();
            this.dtpDatumOd = new System.Windows.Forms.DateTimePicker();
            this.dtpDatumDo = new System.Windows.Forms.DateTimePicker();
            this.txtUkupnaCena = new System.Windows.Forms.TextBox();
            this.btnRezervisi = new System.Windows.Forms.Button();
            this.lbxPonude = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // cbxMarka
            // 
            this.cbxMarka.FormattingEnabled = true;
            this.cbxMarka.Location = new System.Drawing.Point(40, 44);
            this.cbxMarka.Name = "cbxMarka";
            this.cbxMarka.Size = new System.Drawing.Size(129, 21);
            this.cbxMarka.TabIndex = 0;
            // 
            // cbxKubikaza
            // 
            this.cbxKubikaza.FormattingEnabled = true;
            this.cbxKubikaza.Location = new System.Drawing.Point(215, 44);
            this.cbxKubikaza.Name = "cbxKubikaza";
            this.cbxKubikaza.Size = new System.Drawing.Size(143, 21);
            this.cbxKubikaza.TabIndex = 1;
            // 
            // cbxModel
            // 
            this.cbxModel.FormattingEnabled = true;
            this.cbxModel.Location = new System.Drawing.Point(40, 103);
            this.cbxModel.Name = "cbxModel";
            this.cbxModel.Size = new System.Drawing.Size(129, 21);
            this.cbxModel.TabIndex = 2;
            // 
            // cbxGorivo
            // 
            this.cbxGorivo.FormattingEnabled = true;
            this.cbxGorivo.Location = new System.Drawing.Point(396, 44);
            this.cbxGorivo.Name = "cbxGorivo";
            this.cbxGorivo.Size = new System.Drawing.Size(127, 21);
            this.cbxGorivo.TabIndex = 3;
            // 
            // cbxKaroserija
            // 
            this.cbxKaroserija.FormattingEnabled = true;
            this.cbxKaroserija.Location = new System.Drawing.Point(215, 103);
            this.cbxKaroserija.Name = "cbxKaroserija";
            this.cbxKaroserija.Size = new System.Drawing.Size(143, 21);
            this.cbxKaroserija.TabIndex = 4;
            // 
            // cbxPogon
            // 
            this.cbxPogon.FormattingEnabled = true;
            this.cbxPogon.Location = new System.Drawing.Point(396, 103);
            this.cbxPogon.Name = "cbxPogon";
            this.cbxPogon.Size = new System.Drawing.Size(127, 21);
            this.cbxPogon.TabIndex = 5;
            // 
            // cbxGodiste
            // 
            this.cbxGodiste.FormattingEnabled = true;
            this.cbxGodiste.Location = new System.Drawing.Point(40, 163);
            this.cbxGodiste.Name = "cbxGodiste";
            this.cbxGodiste.Size = new System.Drawing.Size(129, 21);
            this.cbxGodiste.TabIndex = 6;
            // 
            // cbxBrojVrata
            // 
            this.cbxBrojVrata.FormattingEnabled = true;
            this.cbxBrojVrata.Location = new System.Drawing.Point(215, 163);
            this.cbxBrojVrata.Name = "cbxBrojVrata";
            this.cbxBrojVrata.Size = new System.Drawing.Size(143, 21);
            this.cbxBrojVrata.TabIndex = 7;
            // 
            // cbxMenjac
            // 
            this.cbxMenjac.FormattingEnabled = true;
            this.cbxMenjac.Location = new System.Drawing.Point(396, 163);
            this.cbxMenjac.Name = "cbxMenjac";
            this.cbxMenjac.Size = new System.Drawing.Size(127, 21);
            this.cbxMenjac.TabIndex = 8;
            // 
            // lblMarka
            // 
            this.lblMarka.AutoSize = true;
            this.lblMarka.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMarka.Location = new System.Drawing.Point(36, 21);
            this.lblMarka.Name = "lblMarka";
            this.lblMarka.Size = new System.Drawing.Size(127, 16);
            this.lblMarka.TabIndex = 9;
            this.lblMarka.Text = "Odaberite marku:";
            // 
            // lblKubikaza
            // 
            this.lblKubikaza.AutoSize = true;
            this.lblKubikaza.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKubikaza.Location = new System.Drawing.Point(211, 21);
            this.lblKubikaza.Name = "lblKubikaza";
            this.lblKubikaza.Size = new System.Drawing.Size(146, 16);
            this.lblKubikaza.TabIndex = 10;
            this.lblKubikaza.Text = "Odaberite kubikažu:";
            // 
            // lblGorivo
            // 
            this.lblGorivo.AutoSize = true;
            this.lblGorivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGorivo.Location = new System.Drawing.Point(392, 21);
            this.lblGorivo.Name = "lblGorivo";
            this.lblGorivo.Size = new System.Drawing.Size(129, 16);
            this.lblGorivo.TabIndex = 11;
            this.lblGorivo.Text = "Odaberite gorivo:";
            // 
            // lblModel
            // 
            this.lblModel.AutoSize = true;
            this.lblModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModel.Location = new System.Drawing.Point(36, 80);
            this.lblModel.Name = "lblModel";
            this.lblModel.Size = new System.Drawing.Size(128, 16);
            this.lblModel.TabIndex = 12;
            this.lblModel.Text = "Odaberite model:";
            // 
            // lblKaroserija
            // 
            this.lblKaroserija.AutoSize = true;
            this.lblKaroserija.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKaroserija.Location = new System.Drawing.Point(211, 80);
            this.lblKaroserija.Name = "lblKaroserija";
            this.lblKaroserija.Size = new System.Drawing.Size(154, 16);
            this.lblKaroserija.TabIndex = 13;
            this.lblKaroserija.Text = "Odaberite karoseriju:";
            // 
            // lblPogon
            // 
            this.lblPogon.AutoSize = true;
            this.lblPogon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPogon.Location = new System.Drawing.Point(392, 80);
            this.lblPogon.Name = "lblPogon";
            this.lblPogon.Size = new System.Drawing.Size(129, 16);
            this.lblPogon.TabIndex = 14;
            this.lblPogon.Text = "Odaberite pogon:";
            // 
            // lblGodiste
            // 
            this.lblGodiste.AutoSize = true;
            this.lblGodiste.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGodiste.Location = new System.Drawing.Point(36, 140);
            this.lblGodiste.Name = "lblGodiste";
            this.lblGodiste.Size = new System.Drawing.Size(137, 16);
            this.lblGodiste.TabIndex = 15;
            this.lblGodiste.Text = "Odaberite godište:";
            // 
            // lblBrojVrata
            // 
            this.lblBrojVrata.AutoSize = true;
            this.lblBrojVrata.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBrojVrata.Location = new System.Drawing.Point(211, 140);
            this.lblBrojVrata.Name = "lblBrojVrata";
            this.lblBrojVrata.Size = new System.Drawing.Size(151, 16);
            this.lblBrojVrata.TabIndex = 16;
            this.lblBrojVrata.Text = "Odaberite broj vrata:";
            // 
            // lblMenjac
            // 
            this.lblMenjac.AutoSize = true;
            this.lblMenjac.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMenjac.Location = new System.Drawing.Point(392, 140);
            this.lblMenjac.Name = "lblMenjac";
            this.lblMenjac.Size = new System.Drawing.Size(135, 16);
            this.lblMenjac.TabIndex = 17;
            this.lblMenjac.Text = "Odaberite menjač:";
            // 
            // btnPrikaziTermine
            // 
            this.btnPrikaziTermine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrikaziTermine.Location = new System.Drawing.Point(39, 207);
            this.btnPrikaziTermine.Name = "btnPrikaziTermine";
            this.btnPrikaziTermine.Size = new System.Drawing.Size(484, 36);
            this.btnPrikaziTermine.TabIndex = 18;
            this.btnPrikaziTermine.Text = "Prikaži slobodne termine odabranog automobila";
            this.btnPrikaziTermine.UseVisualStyleBackColor = true;
            this.btnPrikaziTermine.Click += new System.EventHandler(this.btnPrikaziTermine_Click);
            // 
            // lblDatumPreuzimanja
            // 
            this.lblDatumPreuzimanja.AutoSize = true;
            this.lblDatumPreuzimanja.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatumPreuzimanja.Location = new System.Drawing.Point(37, 390);
            this.lblDatumPreuzimanja.Name = "lblDatumPreuzimanja";
            this.lblDatumPreuzimanja.Size = new System.Drawing.Size(215, 16);
            this.lblDatumPreuzimanja.TabIndex = 20;
            this.lblDatumPreuzimanja.Text = "Odaberite datum preuzimanja:";
            // 
            // lblUkupnaCena
            // 
            this.lblUkupnaCena.AutoSize = true;
            this.lblUkupnaCena.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUkupnaCena.Location = new System.Drawing.Point(339, 461);
            this.lblUkupnaCena.Name = "lblUkupnaCena";
            this.lblUkupnaCena.Size = new System.Drawing.Size(184, 16);
            this.lblUkupnaCena.TabIndex = 21;
            this.lblUkupnaCena.Text = "Ukupna cena rezervacije:";
            // 
            // lblDatumVracanja
            // 
            this.lblDatumVracanja.AutoSize = true;
            this.lblDatumVracanja.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatumVracanja.Location = new System.Drawing.Point(37, 461);
            this.lblDatumVracanja.Name = "lblDatumVracanja";
            this.lblDatumVracanja.Size = new System.Drawing.Size(191, 16);
            this.lblDatumVracanja.TabIndex = 22;
            this.lblDatumVracanja.Text = "Odaberite datum vraćanja:";
            // 
            // dtpDatumOd
            // 
            this.dtpDatumOd.Location = new System.Drawing.Point(39, 423);
            this.dtpDatumOd.Name = "dtpDatumOd";
            this.dtpDatumOd.Size = new System.Drawing.Size(200, 20);
            this.dtpDatumOd.TabIndex = 23;
            this.dtpDatumOd.ValueChanged += new System.EventHandler(this.dtpDatumOd_ValueChanged_1);
            // 
            // dtpDatumDo
            // 
            this.dtpDatumDo.Location = new System.Drawing.Point(40, 491);
            this.dtpDatumDo.Name = "dtpDatumDo";
            this.dtpDatumDo.Size = new System.Drawing.Size(200, 20);
            this.dtpDatumDo.TabIndex = 24;
            this.dtpDatumDo.ValueChanged += new System.EventHandler(this.dtpDatumDo_ValueChanged_1);
            // 
            // txtUkupnaCena
            // 
            this.txtUkupnaCena.Location = new System.Drawing.Point(340, 491);
            this.txtUkupnaCena.Name = "txtUkupnaCena";
            this.txtUkupnaCena.Size = new System.Drawing.Size(181, 20);
            this.txtUkupnaCena.TabIndex = 25;
            // 
            // btnRezervisi
            // 
            this.btnRezervisi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRezervisi.Location = new System.Drawing.Point(39, 539);
            this.btnRezervisi.Name = "btnRezervisi";
            this.btnRezervisi.Size = new System.Drawing.Size(488, 41);
            this.btnRezervisi.TabIndex = 26;
            this.btnRezervisi.Text = "Rezerviši";
            this.btnRezervisi.UseVisualStyleBackColor = true;
            this.btnRezervisi.Click += new System.EventHandler(this.btnRezervisi_Click);
            // 
            // lbxPonude
            // 
            this.lbxPonude.FormattingEnabled = true;
            this.lbxPonude.Location = new System.Drawing.Point(40, 250);
            this.lbxPonude.Name = "lbxPonude";
            this.lbxPonude.Size = new System.Drawing.Size(481, 134);
            this.lbxPonude.TabIndex = 27;
            // 
            // Rezervisi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 591);
            this.Controls.Add(this.lbxPonude);
            this.Controls.Add(this.btnRezervisi);
            this.Controls.Add(this.txtUkupnaCena);
            this.Controls.Add(this.dtpDatumDo);
            this.Controls.Add(this.dtpDatumOd);
            this.Controls.Add(this.lblDatumVracanja);
            this.Controls.Add(this.lblUkupnaCena);
            this.Controls.Add(this.lblDatumPreuzimanja);
            this.Controls.Add(this.btnPrikaziTermine);
            this.Controls.Add(this.lblMenjac);
            this.Controls.Add(this.lblBrojVrata);
            this.Controls.Add(this.lblGodiste);
            this.Controls.Add(this.lblPogon);
            this.Controls.Add(this.lblKaroserija);
            this.Controls.Add(this.lblModel);
            this.Controls.Add(this.lblGorivo);
            this.Controls.Add(this.lblKubikaza);
            this.Controls.Add(this.lblMarka);
            this.Controls.Add(this.cbxMenjac);
            this.Controls.Add(this.cbxBrojVrata);
            this.Controls.Add(this.cbxGodiste);
            this.Controls.Add(this.cbxPogon);
            this.Controls.Add(this.cbxKaroserija);
            this.Controls.Add(this.cbxGorivo);
            this.Controls.Add(this.cbxModel);
            this.Controls.Add(this.cbxKubikaza);
            this.Controls.Add(this.cbxMarka);
            this.Name = "Rezervisi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Rezervisi_FormClosing);
            this.Load += new System.EventHandler(this.Rezervisi_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbxMarka;
        private System.Windows.Forms.ComboBox cbxKubikaza;
        private System.Windows.Forms.ComboBox cbxModel;
        private System.Windows.Forms.ComboBox cbxGorivo;
        private System.Windows.Forms.ComboBox cbxKaroserija;
        private System.Windows.Forms.ComboBox cbxPogon;
        private System.Windows.Forms.ComboBox cbxGodiste;
        private System.Windows.Forms.ComboBox cbxBrojVrata;
        private System.Windows.Forms.ComboBox cbxMenjac;
        private System.Windows.Forms.Label lblMarka;
        private System.Windows.Forms.Label lblKubikaza;
        private System.Windows.Forms.Label lblGorivo;
        private System.Windows.Forms.Label lblModel;
        private System.Windows.Forms.Label lblKaroserija;
        private System.Windows.Forms.Label lblPogon;
        private System.Windows.Forms.Label lblGodiste;
        private System.Windows.Forms.Label lblBrojVrata;
        private System.Windows.Forms.Label lblMenjac;
        private System.Windows.Forms.Button btnPrikaziTermine;
        private System.Windows.Forms.Label lblDatumPreuzimanja;
        private System.Windows.Forms.Label lblUkupnaCena;
        private System.Windows.Forms.Label lblDatumVracanja;
        private System.Windows.Forms.DateTimePicker dtpDatumOd;
        private System.Windows.Forms.DateTimePicker dtpDatumDo;
        private System.Windows.Forms.TextBox txtUkupnaCena;
        private System.Windows.Forms.Button btnRezervisi;
        private System.Windows.Forms.ListBox lbxPonude;
    }
}

