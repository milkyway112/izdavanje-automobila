﻿namespace Projekat
{
    partial class DodajIliUkloniAutomobil
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbxAutomobili = new System.Windows.Forms.ListBox();
            this.btnIzlistajAutomobila = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.txtMarka = new System.Windows.Forms.TextBox();
            this.txtKubikaza = new System.Windows.Forms.TextBox();
            this.txtGorivo = new System.Windows.Forms.TextBox();
            this.txtModel = new System.Windows.Forms.TextBox();
            this.txtKaroserija = new System.Windows.Forms.TextBox();
            this.txtPogon = new System.Windows.Forms.TextBox();
            this.txtGodiste = new System.Windows.Forms.TextBox();
            this.txtBrojVrata = new System.Windows.Forms.TextBox();
            this.txtMenjac = new System.Windows.Forms.TextBox();
            this.lblMarka = new System.Windows.Forms.Label();
            this.lblKubikaza = new System.Windows.Forms.Label();
            this.lblGorivo = new System.Windows.Forms.Label();
            this.lblModel = new System.Windows.Forms.Label();
            this.lblKaroserija = new System.Windows.Forms.Label();
            this.lblPogon = new System.Windows.Forms.Label();
            this.lblGodiste = new System.Windows.Forms.Label();
            this.lblBrojVrata = new System.Windows.Forms.Label();
            this.lblMenjac = new System.Windows.Forms.Label();
            this.btnDodajAutomobil = new System.Windows.Forms.Button();
            this.gbxDodavanjeAutomobil = new System.Windows.Forms.GroupBox();
            this.gbxBrisanjeAutomobila = new System.Windows.Forms.GroupBox();
            this.gbxDodavanjeAutomobil.SuspendLayout();
            this.gbxBrisanjeAutomobila.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbxAutomobili
            // 
            this.lbxAutomobili.FormattingEnabled = true;
            this.lbxAutomobili.Location = new System.Drawing.Point(6, 73);
            this.lbxAutomobili.Name = "lbxAutomobili";
            this.lbxAutomobili.Size = new System.Drawing.Size(527, 173);
            this.lbxAutomobili.TabIndex = 20;
            // 
            // btnIzlistajAutomobila
            // 
            this.btnIzlistajAutomobila.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzlistajAutomobila.Location = new System.Drawing.Point(6, 19);
            this.btnIzlistajAutomobila.Name = "btnIzlistajAutomobila";
            this.btnIzlistajAutomobila.Size = new System.Drawing.Size(527, 48);
            this.btnIzlistajAutomobila.TabIndex = 21;
            this.btnIzlistajAutomobila.Text = "Izlistaj Automobile";
            this.btnIzlistajAutomobila.UseVisualStyleBackColor = true;
            this.btnIzlistajAutomobila.Click += new System.EventHandler(this.btnIzlistajAutomobila_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(6, 252);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(527, 48);
            this.button1.TabIndex = 22;
            this.button1.Text = "Obriši automobil";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtMarka
            // 
            this.txtMarka.Location = new System.Drawing.Point(6, 36);
            this.txtMarka.Name = "txtMarka";
            this.txtMarka.Size = new System.Drawing.Size(130, 20);
            this.txtMarka.TabIndex = 19;
            // 
            // txtKubikaza
            // 
            this.txtKubikaza.Location = new System.Drawing.Point(171, 36);
            this.txtKubikaza.Name = "txtKubikaza";
            this.txtKubikaza.Size = new System.Drawing.Size(146, 20);
            this.txtKubikaza.TabIndex = 20;
            // 
            // txtGorivo
            // 
            this.txtGorivo.Location = new System.Drawing.Point(346, 36);
            this.txtGorivo.Name = "txtGorivo";
            this.txtGorivo.Size = new System.Drawing.Size(128, 20);
            this.txtGorivo.TabIndex = 21;
            // 
            // txtModel
            // 
            this.txtModel.Location = new System.Drawing.Point(6, 93);
            this.txtModel.Name = "txtModel";
            this.txtModel.Size = new System.Drawing.Size(130, 20);
            this.txtModel.TabIndex = 22;
            // 
            // txtKaroserija
            // 
            this.txtKaroserija.Location = new System.Drawing.Point(171, 93);
            this.txtKaroserija.Name = "txtKaroserija";
            this.txtKaroserija.Size = new System.Drawing.Size(146, 20);
            this.txtKaroserija.TabIndex = 23;
            // 
            // txtPogon
            // 
            this.txtPogon.Location = new System.Drawing.Point(346, 93);
            this.txtPogon.Name = "txtPogon";
            this.txtPogon.Size = new System.Drawing.Size(128, 20);
            this.txtPogon.TabIndex = 24;
            // 
            // txtGodiste
            // 
            this.txtGodiste.Location = new System.Drawing.Point(6, 151);
            this.txtGodiste.Name = "txtGodiste";
            this.txtGodiste.Size = new System.Drawing.Size(130, 20);
            this.txtGodiste.TabIndex = 25;
            // 
            // txtBrojVrata
            // 
            this.txtBrojVrata.Location = new System.Drawing.Point(171, 151);
            this.txtBrojVrata.Name = "txtBrojVrata";
            this.txtBrojVrata.Size = new System.Drawing.Size(147, 20);
            this.txtBrojVrata.TabIndex = 26;
            // 
            // txtMenjac
            // 
            this.txtMenjac.Location = new System.Drawing.Point(346, 151);
            this.txtMenjac.Name = "txtMenjac";
            this.txtMenjac.Size = new System.Drawing.Size(128, 20);
            this.txtMenjac.TabIndex = 27;
            // 
            // lblMarka
            // 
            this.lblMarka.AutoSize = true;
            this.lblMarka.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMarka.Location = new System.Drawing.Point(3, 17);
            this.lblMarka.Name = "lblMarka";
            this.lblMarka.Size = new System.Drawing.Size(123, 16);
            this.lblMarka.TabIndex = 28;
            this.lblMarka.Text = "Odaberite marku";
            // 
            // lblKubikaza
            // 
            this.lblKubikaza.AutoSize = true;
            this.lblKubikaza.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKubikaza.Location = new System.Drawing.Point(168, 17);
            this.lblKubikaza.Name = "lblKubikaza";
            this.lblKubikaza.Size = new System.Drawing.Size(142, 16);
            this.lblKubikaza.TabIndex = 29;
            this.lblKubikaza.Text = "Odaberite kubikazu";
            // 
            // lblGorivo
            // 
            this.lblGorivo.AutoSize = true;
            this.lblGorivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGorivo.Location = new System.Drawing.Point(343, 17);
            this.lblGorivo.Name = "lblGorivo";
            this.lblGorivo.Size = new System.Drawing.Size(125, 16);
            this.lblGorivo.TabIndex = 30;
            this.lblGorivo.Text = "Odaberite gorivo";
            // 
            // lblModel
            // 
            this.lblModel.AutoSize = true;
            this.lblModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModel.Location = new System.Drawing.Point(3, 74);
            this.lblModel.Name = "lblModel";
            this.lblModel.Size = new System.Drawing.Size(124, 16);
            this.lblModel.TabIndex = 31;
            this.lblModel.Text = "Odaberite model";
            // 
            // lblKaroserija
            // 
            this.lblKaroserija.AutoSize = true;
            this.lblKaroserija.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKaroserija.Location = new System.Drawing.Point(168, 74);
            this.lblKaroserija.Name = "lblKaroserija";
            this.lblKaroserija.Size = new System.Drawing.Size(150, 16);
            this.lblKaroserija.TabIndex = 32;
            this.lblKaroserija.Text = "Odaberite karoseriju";
            // 
            // lblPogon
            // 
            this.lblPogon.AutoSize = true;
            this.lblPogon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPogon.Location = new System.Drawing.Point(343, 74);
            this.lblPogon.Name = "lblPogon";
            this.lblPogon.Size = new System.Drawing.Size(125, 16);
            this.lblPogon.TabIndex = 33;
            this.lblPogon.Text = "Odaberite pogon";
            // 
            // lblGodiste
            // 
            this.lblGodiste.AutoSize = true;
            this.lblGodiste.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGodiste.Location = new System.Drawing.Point(3, 132);
            this.lblGodiste.Name = "lblGodiste";
            this.lblGodiste.Size = new System.Drawing.Size(133, 16);
            this.lblGodiste.TabIndex = 34;
            this.lblGodiste.Text = "Odaberite godiste";
            // 
            // lblBrojVrata
            // 
            this.lblBrojVrata.AutoSize = true;
            this.lblBrojVrata.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBrojVrata.Location = new System.Drawing.Point(168, 132);
            this.lblBrojVrata.Name = "lblBrojVrata";
            this.lblBrojVrata.Size = new System.Drawing.Size(147, 16);
            this.lblBrojVrata.TabIndex = 35;
            this.lblBrojVrata.Text = "Odaberite broj vrata";
            // 
            // lblMenjac
            // 
            this.lblMenjac.AutoSize = true;
            this.lblMenjac.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMenjac.Location = new System.Drawing.Point(343, 132);
            this.lblMenjac.Name = "lblMenjac";
            this.lblMenjac.Size = new System.Drawing.Size(131, 16);
            this.lblMenjac.TabIndex = 36;
            this.lblMenjac.Text = "Odaberite menjac";
            // 
            // btnDodajAutomobil
            // 
            this.btnDodajAutomobil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDodajAutomobil.Location = new System.Drawing.Point(6, 186);
            this.btnDodajAutomobil.Name = "btnDodajAutomobil";
            this.btnDodajAutomobil.Size = new System.Drawing.Size(468, 48);
            this.btnDodajAutomobil.TabIndex = 37;
            this.btnDodajAutomobil.Text = "Dodajte automobil";
            this.btnDodajAutomobil.UseVisualStyleBackColor = true;
            this.btnDodajAutomobil.Click += new System.EventHandler(this.btnDodajAutomobil_Click_1);
            // 
            // gbxDodavanjeAutomobil
            // 
            this.gbxDodavanjeAutomobil.Controls.Add(this.btnDodajAutomobil);
            this.gbxDodavanjeAutomobil.Controls.Add(this.lblMenjac);
            this.gbxDodavanjeAutomobil.Controls.Add(this.lblBrojVrata);
            this.gbxDodavanjeAutomobil.Controls.Add(this.lblGodiste);
            this.gbxDodavanjeAutomobil.Controls.Add(this.lblPogon);
            this.gbxDodavanjeAutomobil.Controls.Add(this.lblKaroserija);
            this.gbxDodavanjeAutomobil.Controls.Add(this.lblModel);
            this.gbxDodavanjeAutomobil.Controls.Add(this.lblGorivo);
            this.gbxDodavanjeAutomobil.Controls.Add(this.lblKubikaza);
            this.gbxDodavanjeAutomobil.Controls.Add(this.lblMarka);
            this.gbxDodavanjeAutomobil.Controls.Add(this.txtMenjac);
            this.gbxDodavanjeAutomobil.Controls.Add(this.txtBrojVrata);
            this.gbxDodavanjeAutomobil.Controls.Add(this.txtGodiste);
            this.gbxDodavanjeAutomobil.Controls.Add(this.txtPogon);
            this.gbxDodavanjeAutomobil.Controls.Add(this.txtKaroserija);
            this.gbxDodavanjeAutomobil.Controls.Add(this.txtModel);
            this.gbxDodavanjeAutomobil.Controls.Add(this.txtGorivo);
            this.gbxDodavanjeAutomobil.Controls.Add(this.txtKubikaza);
            this.gbxDodavanjeAutomobil.Controls.Add(this.txtMarka);
            this.gbxDodavanjeAutomobil.Location = new System.Drawing.Point(35, 12);
            this.gbxDodavanjeAutomobil.Name = "gbxDodavanjeAutomobil";
            this.gbxDodavanjeAutomobil.Size = new System.Drawing.Size(482, 240);
            this.gbxDodavanjeAutomobil.TabIndex = 23;
            this.gbxDodavanjeAutomobil.TabStop = false;
            this.gbxDodavanjeAutomobil.Text = "Dodavanje automobila";
            // 
            // gbxBrisanjeAutomobila
            // 
            this.gbxBrisanjeAutomobila.Controls.Add(this.btnIzlistajAutomobila);
            this.gbxBrisanjeAutomobila.Controls.Add(this.lbxAutomobili);
            this.gbxBrisanjeAutomobila.Controls.Add(this.button1);
            this.gbxBrisanjeAutomobila.Location = new System.Drawing.Point(12, 258);
            this.gbxBrisanjeAutomobila.Name = "gbxBrisanjeAutomobila";
            this.gbxBrisanjeAutomobila.Size = new System.Drawing.Size(539, 306);
            this.gbxBrisanjeAutomobila.TabIndex = 24;
            this.gbxBrisanjeAutomobila.TabStop = false;
            this.gbxBrisanjeAutomobila.Text = "Brisanje Automobila";
            // 
            // DodajIliUkloniAutomobil
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 576);
            this.Controls.Add(this.gbxBrisanjeAutomobila);
            this.Controls.Add(this.gbxDodavanjeAutomobil);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "DodajIliUkloniAutomobil";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DodajIliUkloniAutomobil";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.DodajIliUkloniAutomobil_FormClosing);
            this.gbxDodavanjeAutomobil.ResumeLayout(false);
            this.gbxDodavanjeAutomobil.PerformLayout();
            this.gbxBrisanjeAutomobila.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ListBox lbxAutomobili;
        private System.Windows.Forms.Button btnIzlistajAutomobila;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtMarka;
        private System.Windows.Forms.TextBox txtKubikaza;
        private System.Windows.Forms.TextBox txtGorivo;
        private System.Windows.Forms.TextBox txtModel;
        private System.Windows.Forms.TextBox txtKaroserija;
        private System.Windows.Forms.TextBox txtPogon;
        private System.Windows.Forms.TextBox txtGodiste;
        private System.Windows.Forms.TextBox txtBrojVrata;
        private System.Windows.Forms.TextBox txtMenjac;
        private System.Windows.Forms.Label lblMarka;
        private System.Windows.Forms.Label lblKubikaza;
        private System.Windows.Forms.Label lblGorivo;
        private System.Windows.Forms.Label lblModel;
        private System.Windows.Forms.Label lblKaroserija;
        private System.Windows.Forms.Label lblPogon;
        private System.Windows.Forms.Label lblGodiste;
        private System.Windows.Forms.Label lblBrojVrata;
        private System.Windows.Forms.Label lblMenjac;
        private System.Windows.Forms.Button btnDodajAutomobil;
        private System.Windows.Forms.GroupBox gbxDodavanjeAutomobil;
        private System.Windows.Forms.GroupBox gbxBrisanjeAutomobila;
    }
}